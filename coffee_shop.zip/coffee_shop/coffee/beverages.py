from abc import ABC, abstractmethod

class Beverage(ABC):

    def prepare(self) -> str:
        steps = [
            self.boil_water(),
            self.brew(),
            self.pour_in_cup(),
            self.add_condiments(),
        ]
        return " | ".join(step for step in steps if step)

    def boil_water(self) -> str:
        return "Кипятим воду"

    @abstractmethod
    def brew(self) -> str:
        ...

    def pour_in_cup(self) -> str:
        return "Наливаем в чашку"

    @abstractmethod
    def add_condiments(self) -> str:
        ...


class Coffee(Beverage):
    def brew(self) -> str:
        return "Завариваем кофе"

    def add_condiments(self) -> str:
        return "Добавляем сахар и молоко"


class Tea(Beverage):
    def brew(self) -> str:
        return "Завариваем чай"

    def add_condiments(self) -> str:
        return "Добавляем лимон"



class BeverageComponent(ABC):

    @abstractmethod
    def cost(self) -> float:
        ...

    @abstractmethod
    def description(self) -> str:
        ...


class SimpleBeverage(BeverageComponent):

    def __init__(self, beverage: Beverage, base_cost: float, name: str):
        self._beverage = beverage
        self._base_cost = base_cost
        self._name = name

    def cost(self) -> float:
        return self._base_cost

    def description(self) -> str:
        return self._name


class BeverageDecorator(BeverageComponent):

    def __init__(self, component: BeverageComponent):
        self._component = component

    def cost(self) -> float:
        return self._component.cost()

    def description(self) -> str:
        return self._component.description()


class MilkDecorator(BeverageDecorator):
    def cost(self) -> float:
        return self._component.cost() + 20.0

    def description(self) -> str:
        return self._component.description() + " + молоко"


class SyrupDecorator(BeverageDecorator):
    def cost(self) -> float:
        return self._component.cost() + 15.0

    def description(self) -> str:
        return self._component.description() + " + сироп"
