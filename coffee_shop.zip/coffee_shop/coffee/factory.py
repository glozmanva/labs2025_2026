from abc import ABC, abstractmethod
from .beverages import Coffee, Tea, SimpleBeverage


class BeverageFactory(ABC):

    @abstractmethod
    def create_beverage(self, beverage_type: str):
        ...


class SimpleBeverageFactory(BeverageFactory):

    BASE_PRICES = {
        "coffee": 120.0,
        "tea": 80.0,
    }

    def create_beverage(self, beverage_type: str):
        beverage_type = beverage_type.lower()
        if beverage_type == "coffee":
            beverage = Coffee()
            return SimpleBeverage(beverage, self.BASE_PRICES["coffee"], "Кофе")
        if beverage_type == "tea":
            beverage = Tea()
            return SimpleBeverage(beverage, self.BASE_PRICES["tea"], "Чай")
        raise ValueError(f"Неизвестный тип напитка: {beverage_type}")
