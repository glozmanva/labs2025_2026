import pytest
from coffee.beverages import Coffee, Tea, SimpleBeverage, MilkDecorator, SyrupDecorator


def test_coffee_prepare_template_method():
    coffee = Coffee()
    process = coffee.prepare()

    assert "Кипятим воду" in process
    assert "Завариваем кофе" in process
    assert "Добавляем сахар и молоко" in process


def test_tea_prepare_template_method():
    tea = Tea()
    process = tea.prepare()

    assert "Кипятим воду" in process
    assert "Завариваем чай" in process
    assert "Добавляем лимон" in process


def test_decorator_cost_and_description():
    base = SimpleBeverage(Coffee(), base_cost=120.0, name="Кофе")
    with_milk = MilkDecorator(base)
    with_milk_and_syrup = SyrupDecorator(with_milk)

    assert with_milk_and_syrup.cost() == pytest.approx(155.0)
    assert with_milk_and_syrup.description() == "Кофе + молоко + сироп"
