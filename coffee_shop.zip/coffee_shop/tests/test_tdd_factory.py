import pytest
from coffee.factory import SimpleBeverageFactory
from coffee.beverages import SimpleBeverage


def test_factory_creates_coffee():
    factory = SimpleBeverageFactory()
    beverage = factory.create_beverage("coffee")

    assert isinstance(beverage, SimpleBeverage)
    assert beverage.description() == "Кофе"
    assert beverage.cost() > 0


def test_factory_unknown_type():
    factory = SimpleBeverageFactory()

    with pytest.raises(ValueError):
        factory.create_beverage("unknown")
