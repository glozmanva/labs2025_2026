def test_factory_uses_base_prices_mock(mocker):
    from coffee.factory import SimpleBeverageFactory

    factory = SimpleBeverageFactory()
    mocker.patch.object(factory, "BASE_PRICES", {"coffee": 1.0, "tea": 1.0})

    beverage = factory.create_beverage("coffee")

    assert beverage.cost() == 1.0
