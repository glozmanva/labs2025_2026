import pytest
from pytest_bdd import given, when, then, scenario, parsers, scenarios
from coffee.factory import SimpleBeverageFactory
from coffee.beverages import MilkDecorator, SyrupDecorator

@scenario("features/order_coffee.feature", "Клиент заказывает кофе с молоком и сиропом")
def test_order_coffee():
    pass

@given("в системе есть фабрика напитков", target_fixture="beverage_factory")
def beverage_factory():
    return SimpleBeverageFactory()

@when(parsers.parse('клиент заказывает "{kind}" с молоком и сиропом'), target_fixture="order_with_addons")
def order_with_addons(beverage_factory, kind):
    base = beverage_factory.create_beverage(kind)
    with_milk = MilkDecorator(base)
    with_syrup = SyrupDecorator(with_milk)
    return with_syrup

@then(parsers.parse("итоговая стоимость заказа равна {price:f}"))
def check_price(order_with_addons, price):
    assert order_with_addons.cost() == price

@then(parsers.parse('описание заказа равно "{description}"'))
def check_description(order_with_addons, description):
    assert order_with_addons.description() == description
